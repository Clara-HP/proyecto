
package problema1;

public class Main {

    public static void main(String[] args) {
       NewClass al = new NewClass();
       al.
       /*al.agregar(new Nodo(14), al.getRaiz());
       al.recorrerPreorden(al.getRaiz());*/
    }
    
}
